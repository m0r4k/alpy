rpcuser=<RPCUSER>
rpcpassword=<RPCPWD>
rpcport=<RPCPORT>

server=1
rpcallowip=127.0.0.1
listen=1
daemon=1
logtimestamps=1
maxconnections=256

#masternode=1
printtodebuglog=0
externalip=<EXTIP>

#bind=<EXTIP>:8890
#masternodeprivkey=<PRIVKEY>
